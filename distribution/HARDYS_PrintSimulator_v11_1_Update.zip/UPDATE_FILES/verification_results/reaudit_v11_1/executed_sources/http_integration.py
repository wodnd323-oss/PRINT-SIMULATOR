"""Isolated HTTP integration of staged V11.1. Never targets the installed port."""
from pathlib import Path
import hashlib,io,json,re,subprocess,sys,time,traceback,urllib.parse
from http.client import HTTPConnection
import numpy as np
from PIL import Image,ImageCms

R=Path(__file__).resolve().parent;B=(R/'staged/HARDYS_PrintSimulator_v11').resolve()
INSTALLED=Path('C:/Users/ju/Downloads/HARDYS_PrintSimulator_v10')
expected_root=hashlib.sha256(str(B).casefold().encode()).hexdigest()[:20]
report={'stage':str(B),'expected_root_id':expected_root,'checks':{},'passed':False,'shutdown_confirmed':False}
base=None;token=None;verified_stage=False

def http(path,data=None,mime='application/json',raw=False):
 headers={}
 if data is not None:
  headers={'X-Hardys-Token':token,'Content-Type':mime}
  if not isinstance(data,bytes):data=json.dumps(data).encode()
 parsed=urllib.parse.urlsplit(base);connection=HTTPConnection('127.0.0.1',parsed.port,timeout=120)
 try:
  connection.request('POST' if data is not None else 'GET',path,body=data,headers=headers)
  response=connection.getresponse();payload=response.read()
  if response.status!=200:raise RuntimeError(str(response.status)+' '+payload.decode('utf8',errors='replace'))
 finally:connection.close()
 return payload if raw else json.loads(payload)

def job(identifier):
 deadline=time.monotonic()+180
 while time.monotonic()<deadline:
  result=http('/api/job?id='+identifier)
  if result['status']=='done':return result['result']
  if result['status']=='error':raise RuntimeError(result['error'])
  time.sleep(.15)
 raise TimeoutError('staged job timed out')

def upload(path,kind='rgb'):
 submitted=http('/api/'+kind+'?name='+urllib.parse.quote(path.name),path.read_bytes(),'application/pdf' if kind=='pdf' else 'image/png')
 return job(submitted['job'])

def image(asset):
 with Image.open(io.BytesIO(http('/'+urllib.parse.quote(asset,safe='/'),raw=True))) as im:return np.array(im.convert('RGB'))

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

try:
 launch=subprocess.run([str(B/'runtime/python/python.exe'),'-B','-I','-X','utf8',str(B/'launch.py'),'--no-open'],cwd=B,capture_output=True,text=True,encoding='utf8',timeout=120,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 if launch.returncode:raise RuntimeError('stage launch failed: '+launch.stdout+launch.stderr)
 match=re.search(r'HARDYS_READY (http://127\.0\.0\.1:(\d+))',launch.stdout)
 assert match,'launch did not return local ready URL'
 base=match.group(1);assert int(match.group(2))!=63759,'refusing installed server port'
 health=http('/health');assert health['root_id']==expected_root,health
 verified_stage=True;report['health']=health;report['url']=base
 assert health['version']==11 and health['revision']=='11.1',health
 token=http('/api/session')['token']
 report['checks']['health_11_1']=True
 state=http('/api/state');assert state['catalog']['cases'][0]['id']=='delivered_case7_v11'

 # Source data and empirical calibration must not change with proof correction.
 photo=state['catalog']['photo']
 preserved=['default_calibration.json','assets/reference_v11/page_01_source.png',photo]
 source_hashes={}
 for relative in preserved:
  staged=digest(B/relative);original=digest(INSTALLED/relative);assert staged==original,(relative,staged,original)
  source_hashes[relative]=staged
 report['checks']['empirical_source_model_photo_unchanged']=source_hashes

 gamma=upload(R/'icc/linear_gamma_rgb.png')
 gamma_pixels=image(gamma['pages'][0]['source'])
 assert gamma_pixels[0,0].tolist()==[188,137,99],gamma_pixels[0,0]
 assert gamma['gamut_info']['color_metadata_used']=='PNG gAMA/cHRM' and gamma['gamut_info']['render_revision']=='11.1'
 report['checks']['gamma1_source_pixel']={'rgb':gamma_pixels[0,0].tolist(),'source':gamma['pages'][0]['source'],'metadata':gamma['gamut_info']['color_metadata_used']}
 zero=job(http('/api/preview',{'asset':gamma['pages'][0]['source'],'strength':0})['job']);assert np.array_equal(image(zero['matched']),gamma_pixels)
 report['checks']['photo_strength_zero_equals_corrected_source']=True

 gray=upload(R/'icc/png_cases/gray16_exact_trns.png');gray_pixels=image(gray['pages'][0]['source'])
 assert gray_pixels[0,1].tolist()==[255,255,255] and gray_pixels[0,0].tolist()==[156,156,156] and gray_pixels[0,2].tolist()==[156,156,156]
 report['checks']['gray16_native_trns']={'transparent':gray_pixels[0,1].tolist(),'neighbors':[gray_pixels[0,0].tolist(),gray_pixels[0,2].tolist()]}

 wide_path=R/'wide_rgb_integration/opaque_a98.png';wide=upload(wide_path)
 with Image.open(wide_path) as im:
  im.load();source=ImageCms.ImageCmsProfile(io.BytesIO(im.info['icc_profile']));srgb=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB'));fogra=ImageCms.getOpenProfile(str(B/'icc/CoatedFOGRA39.icc'))
  flags=ImageCms.Flags.SOFTPROOFING|ImageCms.Flags.BLACKPOINTCOMPENSATION
  oracle=np.asarray(ImageCms.applyTransform(im,ImageCms.buildProofTransformFromOpenProfiles(source,srgb,fogra,'RGB','RGB',renderingIntent=1,proofRenderingIntent=1,flags=flags)))
  ref=np.asarray(ImageCms.profileToProfile(im,source,srgb,outputMode='RGB',renderingIntent=1,flags=ImageCms.Flags.BLACKPOINTCOMPENSATION))
 actual=image(wide['pages'][0]['relative']);assert np.array_equal(actual,oracle)
 assert np.array_equal(image(wide['pages'][0]['source']),ref)
 assert wide['gamut_info']['color_metadata_used']=='ICC' and 'original profile' in wide['gamut_info']['standard_input']
 report['checks']['wide_gamut_original_icc_standard']={'maximum_oracle_difference':0,'source':wide['pages'][0]['source'],'standard':wide['pages'][0]['relative'],'profile':wide['gamut_info']['source_profile'],'standard_input':wide['gamut_info']['standard_input']}

 pdf_file=R/'icc/same_fogra.pdf';pdf=upload(pdf_file,'pdf');prefix=pdf['pages'][0]['source'].rsplit('/',1)[0]
 info=http('/'+prefix+'/preview_info.json');assert info['render_revision']=='11.1' and 'BPC off' in info['relative']
 files=[prefix+'/preview_info.json',pdf['pages'][0]['source'],pdf['pages'][0]['relative']]
 before={name:((B/name).stat().st_mtime_ns,digest(B/name)) for name in files}
 second=upload(pdf_file,'pdf');after={name:((B/name).stat().st_mtime_ns,digest(B/name)) for name in files}
 assert second['id']==pdf['id'] and before==after
 report['checks']['pdf_revision_and_cache']={'revision':info['render_revision'],'same_record_id':True,'cached_render_mtime_and_bytes_unchanged':True,'source_rendering':info['source_rendering'],'standard_rendering':info['relative']}
 report['passed']=True
except Exception:
 report['error']=traceback.format_exc()
finally:
 if verified_stage and base:
  try:
   if token is None:token=http('/api/session')['token']
   assert http('/health')['root_id']==expected_root
   assert urllib.parse.urlsplit(base).port!=63759
   report['shutdown_requested']=http('/api/shutdown',{})
   for _ in range(30):
    try:http('/health')
    except Exception:report['shutdown_confirmed']=True;break
    time.sleep(.1)
  except Exception:report['shutdown_error']=traceback.format_exc()
 report['status']='PASS' if report['passed'] and report['shutdown_confirmed'] else 'FAIL'
 (R/'integrated_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
assert report['passed'] and report['shutdown_confirmed']
