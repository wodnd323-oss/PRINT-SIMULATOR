from pathlib import Path
import sys,hashlib,json,importlib.util,statistics
sys.dont_write_bytecode=True
APP=Path('C:/Users/ju/Downloads/HARDYS_PrintSimulator_v10');OUT=Path('work/reaudit_v11');OUT.mkdir(exist_ok=True,parents=True)
sys.path.insert(0,str(APP))
import numpy as np
from PIL import Image
from color_model import PhotoModel,rgb_to_lab,lab_to_rgb,read_srgb,kernel,WHITE,XYZ
doc=json.loads((APP/'state/calibration.json').read_text('utf8'));default=json.loads((APP/'default_calibration.json').read_text('utf8'))
anchors=[a for a in doc['anchors'] if a.get('enabled',True)];m=PhotoModel(doc)
sr=np.array([a['source_rgb'] for a in anchors]);tr=np.array([a['target_rgb'] for a in anchors]);pred=np.rint(m.transform(sr)).astype(int)
def de(x,y):return np.linalg.norm(rgb_to_lab(x)-rgb_to_lab(y),axis=-1)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
report={'app':str(APP),'state_equals_default':doc==default,'hashes':{p:sha(APP/p) for p in ['color_model.py','default_calibration.json','state/calibration.json','reference_archive/delivered_case7.pdf','assets/printed_case_reference.png','icc/GRACoL2013_CRPC6.icc',anchors[0]['reference_asset']]},'input_pipeline':doc['pipeline']}
report['training']={'n':len(anchors),'unique_input_rgb':len(np.unique(sr,axis=0)),'mean_before':float(de(sr,tr).mean()),'mean_after':float(de(pred,tr).mean()),'max_after':float(de(pred,tr).max())}
def holdout(indices,label):
 train=[a for i,a in enumerate(anchors) if i not in indices]
 mm=PhotoModel(dict(doc,anchors=train));inputs=sr[indices];targets=tr[indices];p=np.rint(mm.transform(inputs)).astype(int);err=de(p,targets)
 return {'group':label,'held_out_ids':[anchors[i]['id'] for i in indices],'training_n':len(train),'mean_delta_e76_before':float(de(inputs,targets).mean()),'mean_delta_e76':float(err.mean()),'max_delta_e76':float(err.max()),'results':[{'id':anchors[i]['id'],'target_rgb':tr[i].tolist(),'input_rgb':sr[i].tolist(),'predicted_rgb':p[k].tolist(),'delta_e76':float(err[k])} for k,i in enumerate(indices)]}
report['leave_distinct_input_color_out']=[holdout(np.where(np.all(sr==v,axis=1))[0].tolist(),','.join(map(str,v))) for v in np.unique(sr,axis=0)]
allerr=[v['delta_e76'] for g in report['leave_distinct_input_color_out'] for v in g['results']]
report['leave_distinct_input_color_out_summary']={'mean_across_13_patches':float(np.mean(allerr)),'mean_across_10_group_means':float(np.mean([g['mean_delta_e76'] for g in report['leave_distinct_input_color_out']])),'max':max(allerr)}
report['leave_family_out']=[holdout([i for i,a in enumerate(anchors) if family in a['label']],family) for family in ['blue','gold']]
report['leave_panel_out']=[holdout([i for i,a in enumerate(anchors) if a['panel']==panel],panel) for panel in ['front','back']]
report['identical_inputs']=[{'input_rgb':v.tolist(),'ids':[anchors[i]['id'] for i in ids],'photo_rgbs':tr[ids].tolist(),'max_pairwise_photo_delta_e76':float(np.max(de(tr[ids][:,None],tr[ids][None,:])))} for v in np.unique(sr,axis=0) if len(ids:=np.where(np.all(sr==v,axis=1))[0])>1]
minimum_squared_error=0.
for group in report['identical_inputs']:
 labs=rgb_to_lab(group['photo_rgbs']);center=labs.mean(axis=0);sse=float(np.sum((labs-center)**2));minimum_squared_error+=sse
 group.update(target_lab_centroid=center.tolist(),minimum_possible_group_rmse_delta_e76=float(np.sqrt(sse/len(labs))),minimum_possible_worst_error_at_least=group['max_pairwise_photo_delta_e76']/2,photo_rgb_population_std=np.std(group['photo_rgbs'],axis=0).tolist())
report['deterministic_color_map_error_floor']={'minimum_possible_rmse_across_13_patches':float(np.sqrt(minimum_squared_error/len(anchors))),'minimum_possible_worst_patch_error_at_least':max(g['minimum_possible_worst_error_at_least'] for g in report['identical_inputs']),'meaning':'Unconstrained Lab-output deterministic function; duplicate-input target variance cannot be fitted away. 8-bit and model constraints may increase this floor.'}
def unclipped_from_lab(lab):
 fy=(lab[...,0]+16)/116;f=np.stack((fy+lab[...,1]/500,fy,fy-lab[...,2]/200),axis=-1);d=6/29
 t=np.where(f>d,f**3,3*d*d*(f-4/29));lin=(t*WHITE)@np.linalg.inv(XYZ).T
 return np.where(lin<=.0031308,lin*12.92,1.055*np.maximum(lin,0)**(1/2.4)-.055)*255
axis=np.linspace(0,255,33).round();rgb=np.stack(np.meshgrid(axis,axis,axis,indexing='ij'),axis=-1).reshape(-1,3)
lab=rgb_to_lab(rgb);adjusted=m.global_lab(lab);dist=np.linalg.norm(lab[:,None,:]-m.source,axis=-1);chroma=np.linalg.norm(lab[:,1:],axis=-1,keepdims=True)
adjusted+=kernel(dist,m.radius)@m.residual_weights*np.clip((chroma-8)/8,0,1)
delta=adjusted-lab;u=np.clip((chroma-8)/8,0,1);delta*=u*u*(3-2*u);norm=np.linalg.norm(delta,axis=-1,keepdims=True);delta*=np.minimum(1,m.max_delta/np.maximum(norm,1e-8))
raw=unclipped_from_lab(lab+delta);trans=m.transform(rgb);assert np.max(np.abs(np.clip(raw,0,255)-trans))<1e-9
rounded=np.rint(trans).astype(int);unique,counts=np.unique(rounded,axis=0,return_counts=True)
report['full_rgb_grid']={'n':len(rgb),'finite':bool(np.isfinite(trans).all()),'min':float(trans.min()),'max':float(trans.max()),'distinct_output_rgb':len(unique),'distinct_fraction':len(unique)/len(rgb),'max_input_collisions_at_one_output':int(counts.max()),'pre_display_clipping_pixel_fraction':float(np.any((raw < -1e-5)|(raw>255+1e-5),axis=1).mean()),'preclip_negative_channel_fraction':float((raw < -1e-5).mean()),'preclip_above255_channel_fraction':float((raw>255+1e-5).mean()),'saturated_lab_delta_count':int((norm[:,0]>32).sum()),'max_actual_lab_delta_after_rgb_clipping':float(de(rgb,trans).max()),'mean_actual_lab_delta':float(de(rgb,trans).mean()),'near_reference_le12_fraction':float((dist.min(axis=1)<=12).mean()),'nearest_reference_distance_minmax':[float(dist.min(axis=1).min()),float(dist.min(axis=1).max())]}
actual_de=de(rgb,trans);imax=int(np.argmax(actual_de));unsupported=dist.min(axis=1)>=m.radius
report['full_rgb_grid'].update(unsupported_ge26_fraction=float(unsupported.mean()),mean_unsupported_delta_e76=float(actual_de[unsupported].mean()),max_delta32_exceeded_after_rgb_clipping_count=int((actual_de>32+1e-5).sum()),worst_clipping_example={'input_rgb':rgb[imax].tolist(),'intermediate_lab_delta':float(np.linalg.norm(delta[imax])),'unclipped_rgb':raw[imax].tolist(),'display_rgb':trans[imax].tolist(),'actual_delta_e76':float(actual_de[imax])},sampling_note='33 evenly spaced rounded channel values, 35,937 samples; not exhaustive 256^3 input coverage and not a natural-image prevalence estimate.')
gray=np.arange(256)[:,None].repeat(3,axis=1);report['neutral_ramp']={'unchanged_8bit':bool(np.array_equal(np.rint(m.transform(gray)),gray))}
report['fit_information']=m.fit_information();report['training_ranges']={'Lstar_minmax':[float(m.source[:,0].min()),float(m.source[:,0].max())],'chroma_minmax':[float(np.linalg.norm(m.source[:,1:],axis=1).min()),float(np.linalg.norm(m.source[:,1:],axis=1).max())],'hue_degrees':np.round(np.rad2deg(np.arctan2(m.source[:,2],m.source[:,1])),3).tolist()}
spec=importlib.util.spec_from_file_location('recorded_calibration',APP/'verification_sources/rebuild_calibration.py');cal=importlib.util.module_from_spec(spec);spec.loader.exec_module(cal)
source,_=read_srgb(APP/anchors[0]['reference_asset']);photo,_=read_srgb(APP/'assets/printed_case_reference.png');sa=np.asarray(source);pa=np.asarray(photo)
allunique=set();reextracted=[];sensitivity=[]
for a in anchors:
 panel=next(v for v in cal.PANELS if v['label']==a['panel']);x0,y0,x1,y1=panel['source_rect'];h=cal.homography(panel['photo_quad']);sx,sy=a['source_xy'];u,v=a['normalized_panel_uv']
 yy,xx=np.meshgrid(np.arange(sy-6,sy+7),np.arange(sx-6,sx+7),indexing='ij');uv=np.column_stack([(xx.ravel()-x0)/(x1-x0),(yy.ravel()-y0)/(y1-y0)]);xy=cal.project(h,uv)
 if 'gold' in a['label']:xy+=np.array(a['target_xy'])-cal.project(h,np.array([[u,v]]))[0]
 tx=np.rint(xy[:,0]).astype(int);ty=np.rint(xy[:,1]).astype(int);sp=sa[yy.ravel(),xx.ravel()].astype(float)
 def extract(dx,dy):
  tp=pa[ty+dy,tx+dx].astype(float);sl=rgb_to_lab(sp);tl=rgb_to_lab(tp);mask=(np.linalg.norm(sl-np.median(sl,axis=0),axis=1)<3)&(np.linalg.norm(tl-np.median(tl,axis=0),axis=1)<5)
  if 'blue' in a['label']:mask&=(sp[:,2]>sp[:,0]+20)&(tp[:,2]>tp[:,0]+20)
  else:mask&=(sp[:,0]>sp[:,2]+30)&(tp[:,0]>tp[:,2]+20)
  return mask,np.rint(np.median(sp[mask],axis=0)).astype(int),np.rint(np.median(tp[mask],axis=0)).astype(int)
 mask,sxrgb,txrgb=extract(0,0);allunique.update(map(tuple,np.column_stack([tx[mask],ty[mask]])))
 reextracted.append({'id':a['id'],'source_match':sxrgb.tolist()==a['source_rgb'],'target_match':txrgb.tolist()==a['target_rgb'],'retained':int(mask.sum())})
 shifts=[]
 for dx,dy in [(1,0),(-1,0),(0,1),(0,-1),(2,0),(-2,0),(0,2),(0,-2)]:
  mask,_,shifted=extract(dx,dy);shifts.append({'shift':[dx,dy],'retained':int(mask.sum()),'delta_e76_from_original_sample':float(de(shifted,txrgb))})
 sensitivity.append({'id':a['id'],'max_delta_from_1px':max(x['delta_e76_from_original_sample'] for x in shifts[:4]),'max_delta_from_2px':max(x['delta_e76_from_original_sample'] for x in shifts[4:]),'shifts':shifts})
report['reextraction']=reextracted;report['distinct_photo_pixels']=len(allunique);report['registration_sensitivity']=sensitivity
(OUT/'calibration_method_evidence.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({k:report[k] for k in ['state_equals_default','training','leave_distinct_input_color_out_summary','identical_inputs','full_rgb_grid','training_ranges']},ensure_ascii=False,indent=2))
print('family',[(x['group'],x['mean_delta_e76'],x['max_delta_e76']) for x in report['leave_family_out']]);print('panel',[(x['group'],x['mean_delta_e76'],x['max_delta_e76']) for x in report['leave_panel_out']]);print('sensitivity',[(x['id'],round(x['max_delta_from_1px'],3),round(x['max_delta_from_2px'],3)) for x in sensitivity])
