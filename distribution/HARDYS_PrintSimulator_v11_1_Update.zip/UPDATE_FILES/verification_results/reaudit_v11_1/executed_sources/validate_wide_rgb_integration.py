from pathlib import Path
import sys,io,json,importlib.util,contextlib,hashlib
sys.dont_write_bytecode=True
import numpy as np
from PIL import Image,ImageCms
APP=Path('C:/Users/ju/Downloads/HARDYS_PrintSimulator_v10')
OUT=Path('work/reaudit_v11/wide_rgb_integration')
FIX=Path(sys.argv[1]) if len(sys.argv)>1 else Path('work/reaudit_v11/icc/fixed/proof_rgb_image.py')
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);module.BASE=APP;return module
old=load('installed_importer',APP/'proof_rgb_image.py');new=load('candidate_importer',FIX)
srgb=ImageCms.ImageCmsProfile(ImageCms.createProfile('sRGB'));fogra=ImageCms.getOpenProfile(str(APP/'icc/CoatedFOGRA39.icc'))
flags=ImageCms.Flags.SOFTPROOFING|ImageCms.Flags.BLACKPOINTCOMPENSATION
def difference(a,b):
 d=np.abs(np.asarray(a,dtype=int)-np.asarray(b,dtype=int));return {'max_channel':int(d.max()),'mean_channel':float(d.mean()),'fraction_any_difference':float(np.any(d,axis=-1).mean())}
report={'source_file':str(FIX),'source_sha256':hashlib.sha256(FIX.read_bytes()).hexdigest(),'tests':[]}
def check(name,actual,expected,tolerance=0,**extra):
 diff=difference(actual,expected);report['tests'].append({'name':name,'passed':diff['max_channel']<=tolerance,'tolerance':tolerance,**diff,**extra})
for name in ['opaque_a98.png','opaque_p3.png','transparent_p3.png','opaque_rgba_p3.png']:
 file=OUT/name;before,_=old.read_image_srgb(file);after,info=new.read_image_srgb(file)
 check('empirical_source_unchanged_'+name,after,before,info=info)
for rel in ['assets/printed_case_reference.png','assets/reference_v11/page_01_source.png']:
 before,_=old.read_image_srgb(APP/rel);after,info=new.read_image_srgb(APP/rel);check('actual_reference_unchanged_'+rel,after,before)
for name,profile,tolerance in [('opaque_a98.png',APP/'runtime/ghostscript/iccprofiles/a98.icc',0),('opaque_p3.png',OUT/'synthetic_display_p3.icc',0),('opaque_rgba_p3.png',OUT/'synthetic_display_p3.icc',0),('opaque_p3_gamma2_chunks.png',OUT/'synthetic_p3_gamma2.icc',2)]:
 with Image.open(OUT/name) as im:
  source=ImageCms.getOpenProfile(str(profile));direct=ImageCms.buildProofTransformFromOpenProfiles(source,srgb,fogra,'RGB','RGB',renderingIntent=1,proofRenderingIntent=1,flags=flags);oracle=ImageCms.applyTransform(im.convert('RGB'),direct)
 destination=OUT/('result_'+Path(name).stem)
 with contextlib.redirect_stdout(io.StringIO()):new.proof_image(OUT/name,destination)
 result=Image.open(destination/'RGB_softproof.png');info=json.loads((destination/'gamut_info.json').read_text('utf8'))
 check('standard_direct_profile_'+name,result,oracle,tolerance,info=info)
# The maintained transparent-preview convention is ICC -> encoded-sRGB white composite.
source,_=old.read_image_srgb(OUT/'transparent_p3.png');direct=ImageCms.buildProofTransformFromOpenProfiles(srgb,srgb,fogra,'RGB','RGB',renderingIntent=1,proofRenderingIntent=1,flags=flags);oracle=ImageCms.applyTransform(source,direct)
destination=OUT/'result_transparent_p3'
with contextlib.redirect_stdout(io.StringIO()):new.proof_image(OUT/'transparent_p3.png',destination)
info=json.loads((destination/'gamut_info.json').read_text('utf8'));check('transparent_documented_srgb_composite',Image.open(destination/'RGB_softproof.png'),oracle,0,info=info)
warnings=' '.join(info.get('input_warnings',[]));report['tests'].append({'name':'transparent_standard_limitation_disclosed','passed':('sRGB' in warnings and ('투명' in warnings or '합성' in warnings)),'warnings':warnings})
report['all_passed']=all(x['passed'] for x in report['tests']);(OUT/'integration_results.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf8')
print(json.dumps({'source_sha256':report['source_sha256'],'all_passed':report['all_passed'],'tests':[{k:v for k,v in x.items() if k!='info'} for x in report['tests']]},ensure_ascii=False,indent=2))
