V11.1의 별도 방법 감사 기록입니다. purpose_checks는 수정 전 실제 설치 V11의 동일성 확인입니다. calibration evidence는 변경하지 않은 사진 모델의 독립 그룹 제외 검사입니다. math/ICC fixed 결과는 오류 수정의 독립 시험입니다. 최종 통합 결과는 integrated_results.json에 기록합니다.
