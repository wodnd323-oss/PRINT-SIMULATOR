HARDYS V11 → V11.1 업데이트입니다. V10 또는 프로그램이 없는 PC에서는 Full_Install ZIP을 사용하세요.
프로그램 종료 → 기존 폴더 전체 백업 → UPDATE_FILES의 내용을 기존 START.cmd 옆에 덮어쓰기 → START.cmd 실행.
사용자 보정·업로드·내보내기는 그대로 둡니다. 이전 가져오기 목록은 원본을 다시 열면 새 계산으로 갱신됩니다.
계산 근거: HARDYS_Calculation_Review_v11_1.txt 또는 web/calculation_review.html
복구: 프로그램 종료 후 별도로 보관한 이전 폴더에서 START.cmd 실행.
